"use client"

import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { Badge } from "@/components/ui/badge"
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Clock, Users, Ticket } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"
import { toast } from "sonner"

export default function MemberEventsPage() {
  const { events } = useData()
  const [activeTab, setActiveTab] = useState("upcoming")

  const filteredEvents = activeTab === "all" ? events : events.filter((e) => e.status === activeTab)

  const statusColors: Record<string, string> = {
    upcoming: "bg-primary/10 text-primary",
    ongoing: "bg-accent/10 text-accent",
    completed: "bg-muted text-muted-foreground",
    cancelled: "bg-destructive/10 text-destructive",
  }

  const statusCounts = {
    all: events.length,
    upcoming: events.filter((e) => e.status === "upcoming").length,
    completed: events.filter((e) => e.status === "completed").length,
  }

  const formatEventDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return {
      day: date.toLocaleDateString("en-US", { day: "numeric" }),
      month: date.toLocaleDateString("en-US", { month: "short" }),
      time: date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
      full: date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" }),
    }
  }

  const handleRegister = (eventTitle: string) => {
    toast.success(`Registered for "${eventTitle}"`)
  }

  return (
    <div className="flex flex-col">
      <Header title="Events" subtitle="Browse and register for club events" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming ({statusCounts.upcoming})</TabsTrigger>
            <TabsTrigger value="completed">Past ({statusCounts.completed})</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Events Grid */}
        {filteredEvents.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar className="mx-auto h-12 w-12 mb-4 opacity-50" />
            <p>No events found</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {filteredEvents.map((event) => {
              const dateInfo = formatEventDate(event.start_date)

              return (
                <Card key={event.id} className="overflow-hidden">
                  <div className="flex">
                    {/* Date Badge */}
                    <div className="w-24 bg-primary/5 flex flex-col items-center justify-center py-6 border-r border-border">
                      <span className="text-3xl font-bold text-primary">{dateInfo.day}</span>
                      <span className="text-sm text-primary/70">{dateInfo.month}</span>
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between mb-2">
                        <CardTitle className="text-lg">{event.title}</CardTitle>
                        <Badge className={cn("capitalize", statusColors[event.status])}>{event.status}</Badge>
                      </div>

                      {event.description && (
                        <CardDescription className="line-clamp-2 mb-4">{event.description}</CardDescription>
                      )}

                      <div className="space-y-2 text-sm text-muted-foreground mb-4">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          <span>{dateInfo.time}</span>
                          {event.end_date && <span>- {formatEventDate(event.end_date).time}</span>}
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            <span>{event.location}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          {event.max_participants && (
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>Max {event.max_participants}</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2">
                            <Ticket className="h-4 w-4" />
                            <span className="font-medium text-foreground">
                              {event.participation_fee && event.participation_fee > 0
                                ? `৳${event.participation_fee}`
                                : "Free"}
                            </span>
                          </div>
                        </div>
                      </div>

                      {event.status === "upcoming" && (
                        <Button size="sm" className="w-full" onClick={() => handleRegister(event.title)}>
                          Register Now
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
