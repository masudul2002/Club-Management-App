"use client"

import type React from "react"

import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Bell, CreditCard, Calendar, AlertTriangle, CheckCircle, Info } from "lucide-react"
import { cn } from "@/lib/utils"

export default function MemberNotificationsPage() {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useData()
  const { user } = useAuth()

  const userNotifications = notifications.filter((n) => n.user_id === user?.id || n.user_id === "3")
  const unreadCount = userNotifications.filter((n) => !n.is_read).length

  const typeIcons: Record<string, React.ReactNode> = {
    payment_reminder: <CreditCard className="h-5 w-5" />,
    due_alert: <AlertTriangle className="h-5 w-5" />,
    suspension_warning: <AlertTriangle className="h-5 w-5" />,
    event: <Calendar className="h-5 w-5" />,
    general: <Info className="h-5 w-5" />,
  }

  const typeColors: Record<string, string> = {
    payment_reminder: "bg-primary/10 text-primary",
    due_alert: "bg-warning/10 text-warning",
    suspension_warning: "bg-destructive/10 text-destructive",
    event: "bg-accent/10 text-accent",
    general: "bg-muted text-muted-foreground",
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Yesterday"
    if (diffDays < 7) return `${diffDays} days ago`
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  return (
    <div className="flex flex-col">
      <Header title="Notifications" subtitle="Stay updated with club activities" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-muted-foreground" />
            <span className="text-muted-foreground">
              {unreadCount > 0 ? `${unreadCount} unread notifications` : "All caught up!"}
            </span>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllNotificationsRead}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark all as read
            </Button>
          )}
        </div>

        {/* Notifications List */}
        {userNotifications.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <Bell className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No notifications</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {userNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={cn(
                  "cursor-pointer transition-colors",
                  !notification.is_read && "border-primary/30 bg-primary/5",
                )}
                onClick={() => markNotificationRead(notification.id)}
              >
                <CardContent className="pt-4">
                  <div className="flex gap-4">
                    <div
                      className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                        typeColors[notification.type],
                      )}
                    >
                      {typeIcons[notification.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium">{notification.title}</p>
                        <div className="flex items-center gap-2 shrink-0">
                          {!notification.is_read && <Badge variant="default" className="h-2 w-2 p-0 rounded-full" />}
                          <span className="text-xs text-muted-foreground">{formatDate(notification.created_at)}</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
