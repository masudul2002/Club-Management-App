"use client"

import { Header } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CreditCard, Calendar, Users, AlertTriangle, CheckCircle, Clock, ArrowRight, AlertCircle } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function MemberPortalPage() {
  const { members, payments, events, committeeMembers, committees, subscription } = useData()
  const { user } = useAuth()

  // Find member profile (in real app, this would be linked to the user)
  const memberProfile = members.find((m) => m.email === user?.email) || members[0]

  const memberPayments = payments.filter((p) => p.member_id === memberProfile?.id)
  const pendingPayments = memberPayments.filter((p) => p.status === "pending")
  const completedPayments = memberPayments.filter((p) => p.status === "completed")

  const memberCommittees = committeeMembers
    .filter((cm) => cm.member_id === memberProfile?.id && cm.is_active)
    .map((cm) => ({
      ...cm,
      committee: committees.find((c) => c.id === cm.committee_id),
    }))

  const upcomingEvents = events.filter((e) => e.status === "upcoming")

  // Calculate dues
  const currentMonth = new Date().getMonth() + 1
  const currentYear = new Date().getFullYear()
  const dueAmount = pendingPayments.reduce((sum, p) => sum + p.total_amount, 0)
  const fineAmount = pendingPayments.reduce((sum, p) => sum + p.fine_amount, 0)

  const statusColors: Record<string, string> = {
    active: "bg-accent text-accent-foreground",
    warning: "bg-warning text-warning-foreground",
    inactive: "bg-muted text-muted-foreground",
    suspended: "bg-destructive text-destructive-foreground",
    resigned: "bg-secondary text-secondary-foreground",
  }

  const paymentStatus =
    memberProfile?.unpaid_months === 0 ? "paid" : memberProfile?.unpaid_months === 1 ? "due" : "overdue"

  return (
    <div className="flex flex-col">
      <Header title="Member Portal" subtitle={`Welcome back, ${memberProfile?.first_name || "Member"}!`} />

      <div className="p-4 md:p-6 space-y-6">
        {/* Status Alert */}
        {memberProfile?.status !== "active" && (
          <Card
            className={cn(
              "border-2",
              memberProfile?.status === "warning" && "border-warning bg-warning/5",
              memberProfile?.status === "inactive" && "border-muted bg-muted/5",
              memberProfile?.status === "suspended" && "border-destructive bg-destructive/5",
            )}
          >
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <AlertCircle
                  className={cn(
                    "h-6 w-6",
                    memberProfile?.status === "warning" && "text-warning",
                    memberProfile?.status === "inactive" && "text-muted-foreground",
                    memberProfile?.status === "suspended" && "text-destructive",
                  )}
                />
                <div>
                  <p className="font-semibold">
                    {memberProfile?.status === "warning" && "Payment Warning"}
                    {memberProfile?.status === "inactive" && "Account Inactive"}
                    {memberProfile?.status === "suspended" && "Account Suspended"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {memberProfile?.status === "warning" &&
                      "You have 1 month of unpaid dues. Please make payment to avoid account deactivation."}
                    {memberProfile?.status === "inactive" &&
                      "Your account is inactive due to 2 months of unpaid dues. Please clear your dues."}
                    {memberProfile?.status === "suspended" &&
                      "Your account has been suspended due to 3+ months of unpaid dues. Please contact admin."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Profile Overview */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">
                  {memberProfile?.first_name[0]}
                  {memberProfile?.last_name[0]}
                </span>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <h2 className="text-xl font-bold">
                    {memberProfile?.first_name} {memberProfile?.last_name}
                  </h2>
                  <Badge className={cn("capitalize", statusColors[memberProfile?.status || "active"])}>
                    {memberProfile?.status}
                  </Badge>
                </div>
                <p className="text-muted-foreground font-mono">{memberProfile?.member_id}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Member since{" "}
                  {memberProfile?.join_date
                    ? new Date(memberProfile.join_date).toLocaleDateString("en-US", { month: "long", year: "numeric" })
                    : "N/A"}
                </p>
              </div>
              <Link href="/portal/profile">
                <Button variant="outline">View Profile</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Payment Status"
            value={paymentStatus === "paid" ? "Paid" : paymentStatus === "due" ? "Due" : "Overdue"}
            description={dueAmount > 0 ? `৳${dueAmount} pending` : "All dues cleared"}
            icon={paymentStatus === "paid" ? CheckCircle : paymentStatus === "due" ? Clock : AlertTriangle}
            className={cn(
              paymentStatus === "paid" && "border-accent/50",
              paymentStatus === "due" && "border-warning/50",
              paymentStatus === "overdue" && "border-destructive/50",
            )}
          />
          <StatsCard
            title="Due Amount"
            value={`৳${dueAmount.toLocaleString()}`}
            description={fineAmount > 0 ? `Includes ৳${fineAmount} fine` : "No fines applied"}
            icon={CreditCard}
          />
          <StatsCard
            title="Upcoming Events"
            value={upcomingEvents.length}
            description="events scheduled"
            icon={Calendar}
          />
          <StatsCard
            title="Committee Roles"
            value={memberCommittees.length}
            description="active positions"
            icon={Users}
          />
        </div>

        {/* Content Grid */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Payment History */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Recent Payments</CardTitle>
                <CardDescription>Your payment history</CardDescription>
              </div>
              <Link href="/portal/payments">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {memberPayments.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No payment records</p>
              ) : (
                <div className="space-y-3">
                  {memberPayments.slice(0, 4).map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                      <div>
                        <p className="font-medium">
                          {payment.period_month}/{payment.period_year}
                        </p>
                        <p className="text-sm text-muted-foreground">Due: {payment.due_date}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">৳{payment.total_amount.toLocaleString()}</p>
                        <Badge
                          variant={payment.status === "completed" ? "default" : "secondary"}
                          className={cn(
                            "capitalize",
                            payment.status === "completed" && "bg-accent text-accent-foreground",
                            payment.status === "pending" && "bg-warning text-warning-foreground",
                          )}
                        >
                          {payment.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Upcoming Events</CardTitle>
                <CardDescription>Events you can participate in</CardDescription>
              </div>
              <Link href="/portal/events">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {upcomingEvents.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No upcoming events</p>
              ) : (
                <div className="space-y-3">
                  {upcomingEvents.slice(0, 3).map((event) => (
                    <div key={event.id} className="p-3 rounded-lg bg-muted/30">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium">{event.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(event.start_date).toLocaleDateString("en-US", {
                              weekday: "short",
                              month: "short",
                              day: "numeric",
                            })}
                          </p>
                        </div>
                        {event.participation_fee && event.participation_fee > 0 ? (
                          <Badge variant="secondary">৳{event.participation_fee}</Badge>
                        ) : (
                          <Badge variant="outline">Free</Badge>
                        )}
                      </div>
                      {event.location && <p className="text-xs text-muted-foreground mt-1">{event.location}</p>}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Committee Positions */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Your Committee Positions</CardTitle>
              <CardDescription>Active roles in club committees</CardDescription>
            </CardHeader>
            <CardContent>
              {memberCommittees.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">You are not a member of any committee</p>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {memberCommittees.map((cm) => (
                    <Card key={cm.id} className="bg-muted/30">
                      <CardContent className="pt-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Users className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{cm.committee?.name}</p>
                            <Badge variant="outline" className="capitalize mt-1">
                              {cm.role.replace("_", " ")}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Payment CTA */}
        {dueAmount > 0 && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="font-semibold text-lg">You have pending dues</h3>
                  <p className="text-muted-foreground">
                    Total amount due: ৳{dueAmount.toLocaleString()}
                    {fineAmount > 0 && ` (includes ৳${fineAmount} late fee)`}
                  </p>
                </div>
                <Link href="/portal/payments">
                  <Button size="lg">
                    <CreditCard className="mr-2 h-5 w-5" />
                    Pay Now
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
