"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, Loader2, CheckCircle, Clock, AlertTriangle } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import type { Payment } from "@/lib/types"

export default function MemberPaymentsPage() {
  const { members, payments, subscription, updatePayment, updateMember } = useData()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("pending")
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const memberProfile = members.find((m) => m.email === user?.email) || members[0]
  const memberPayments = payments.filter((p) => p.member_id === memberProfile?.id)
  const filteredPayments = activeTab === "all" ? memberPayments : memberPayments.filter((p) => p.status === activeTab)

  const pendingTotal = memberPayments.filter((p) => p.status === "pending").reduce((sum, p) => sum + p.total_amount, 0)

  const statusCounts = {
    all: memberPayments.length,
    pending: memberPayments.filter((p) => p.status === "pending").length,
    completed: memberPayments.filter((p) => p.status === "completed").length,
  }

  const statusColors: Record<string, string> = {
    completed: "bg-accent text-accent-foreground",
    pending: "bg-warning text-warning-foreground",
    failed: "bg-destructive text-destructive-foreground",
    refunded: "bg-muted text-muted-foreground",
  }

  const handleBkashPayment = async (payment: Payment) => {
    setIsProcessing(true)

    // Simulate bKash payment
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const txnId = `BK${Date.now().toString().slice(-10)}`

    updatePayment(payment.id, {
      status: "completed",
      payment_date: new Date().toISOString().split("T")[0],
      transaction_id: txnId,
    })

    // Update member status
    if (memberProfile && memberProfile.unpaid_months > 0) {
      const newUnpaidMonths = Math.max(0, memberProfile.unpaid_months - 1)
      let newStatus = memberProfile.status

      if (newUnpaidMonths === 0) {
        newStatus = "active"
      } else if (newUnpaidMonths === 1) {
        newStatus = "warning"
      } else if (newUnpaidMonths === 2) {
        newStatus = "inactive"
      }

      updateMember(memberProfile.id, {
        unpaid_months: newUnpaidMonths,
        status: newStatus,
      })
    }

    setIsProcessing(false)
    setSelectedPayment(null)
    toast.success(`Payment successful! Transaction ID: ${txnId}`)
  }

  return (
    <div className="flex flex-col">
      <Header title="My Payments" subtitle="View and manage your payment history" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Pending Summary */}
        {pendingTotal > 0 && (
          <Card className="border-warning/30 bg-warning/5">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-warning/10 flex items-center justify-center">
                    <AlertTriangle className="h-6 w-6 text-warning" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Pending Amount</p>
                    <p className="text-2xl font-bold">৳{pendingTotal.toLocaleString()}</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Monthly fee: ৳{subscription.amount} | Late fine: {subscription.late_fine_percentage}%
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({statusCounts.pending})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({statusCounts.completed})</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Payment List */}
        {filteredPayments.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <CreditCard className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No payments found</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredPayments.map((payment) => (
              <Card key={payment.id} className="hover:border-primary/30 transition-colors">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          "w-12 h-12 rounded-full flex items-center justify-center",
                          payment.status === "completed" && "bg-accent/10",
                          payment.status === "pending" && "bg-warning/10",
                          payment.status === "failed" && "bg-destructive/10",
                        )}
                      >
                        {payment.status === "completed" && <CheckCircle className="h-6 w-6 text-accent" />}
                        {payment.status === "pending" && <Clock className="h-6 w-6 text-warning" />}
                        {payment.status === "failed" && <AlertTriangle className="h-6 w-6 text-destructive" />}
                      </div>
                      <div>
                        <p className="font-medium">
                          {new Date(0, payment.period_month - 1).toLocaleString("default", { month: "long" })}{" "}
                          {payment.period_year}
                        </p>
                        <p className="text-sm text-muted-foreground">Due: {payment.due_date}</p>
                        {payment.payment_date && <p className="text-sm text-accent">Paid: {payment.payment_date}</p>}
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-lg font-bold">৳{payment.total_amount.toLocaleString()}</p>
                        {payment.fine_amount > 0 && (
                          <p className="text-xs text-destructive">+ ৳{payment.fine_amount} fine</p>
                        )}
                        <Badge className={cn("capitalize mt-1", statusColors[payment.status])}>{payment.status}</Badge>
                      </div>

                      {payment.status === "pending" && (
                        <Button onClick={() => setSelectedPayment(payment)}>Pay Now</Button>
                      )}
                    </div>
                  </div>

                  {payment.transaction_id && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        Transaction ID: <span className="font-mono">{payment.transaction_id}</span>
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Payment Dialog */}
        <Dialog open={!!selectedPayment} onOpenChange={(open) => !open && setSelectedPayment(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Complete Payment</DialogTitle>
              <DialogDescription>
                Pay your dues for{" "}
                {selectedPayment &&
                  new Date(0, selectedPayment.period_month - 1).toLocaleString("default", { month: "long" })}{" "}
                {selectedPayment?.period_year}
              </DialogDescription>
            </DialogHeader>

            {selectedPayment && (
              <div className="space-y-6">
                {/* Payment Summary */}
                <Card className="bg-muted/30">
                  <CardContent className="pt-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Monthly Fee</span>
                      <span>৳{selectedPayment.amount.toLocaleString()}</span>
                    </div>
                    {selectedPayment.fine_amount > 0 && (
                      <div className="flex justify-between text-destructive">
                        <span>Late Payment Fine</span>
                        <span>৳{selectedPayment.fine_amount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-3 border-t border-border">
                      <span className="font-medium">Total</span>
                      <span className="text-lg font-bold">৳{selectedPayment.total_amount.toLocaleString()}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* bKash Payment */}
                <Card className="border-[#E2136E]/30 bg-[#E2136E]/5">
                  <CardContent className="pt-4">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-xl bg-[#E2136E] flex items-center justify-center">
                        <CreditCard className="h-8 w-8 text-white" />
                      </div>
                      <div className="text-center">
                        <p className="font-medium">Pay with bKash</p>
                        <p className="text-sm text-muted-foreground">Secure mobile payment</p>
                      </div>
                      <Button
                        className="w-full bg-[#E2136E] hover:bg-[#E2136E]/90"
                        onClick={() => handleBkashPayment(selectedPayment)}
                        disabled={isProcessing}
                      >
                        {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isProcessing ? "Processing..." : `Pay ৳${selectedPayment.total_amount.toLocaleString()}`}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
