"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { DataTable } from "@/components/dashboard/data-table"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Member } from "@/lib/types"
import { MemberForm } from "@/components/members/member-form"
import { MemberDetails } from "@/components/members/member-details"

export default function MembersPage() {
  const { members } = useData()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState<Member | null>(null)
  const [activeTab, setActiveTab] = useState("all")

  const statusColors: Record<string, string> = {
    active: "bg-accent text-accent-foreground",
    warning: "bg-warning text-warning-foreground",
    inactive: "bg-muted text-muted-foreground",
    suspended: "bg-destructive text-destructive-foreground",
    resigned: "bg-secondary text-secondary-foreground",
  }

  const filteredMembers = activeTab === "all" ? members : members.filter((m) => m.status === activeTab)

  const columns = [
    {
      key: "member_id",
      header: "Member ID",
      render: (member: Member) => <span className="font-mono text-sm">{member.member_id}</span>,
    },
    {
      key: "name",
      header: "Name",
      render: (member: Member) => (
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-xs font-medium text-primary">
              {member.first_name[0]}
              {member.last_name[0]}
            </span>
          </div>
          <span className="font-medium">
            {member.first_name} {member.last_name}
          </span>
        </div>
      ),
    },
    {
      key: "email",
      header: "Email",
      render: (member: Member) => <span className="text-muted-foreground">{member.email}</span>,
    },
    {
      key: "phone",
      header: "Phone",
      render: (member: Member) => <span className="text-muted-foreground">{member.phone}</span>,
    },
    {
      key: "status",
      header: "Status",
      render: (member: Member) => (
        <Badge className={cn("capitalize", statusColors[member.status])}>{member.status}</Badge>
      ),
    },
    {
      key: "unpaid_months",
      header: "Unpaid",
      render: (member: Member) => (
        <span className={member.unpaid_months > 0 ? "text-destructive font-medium" : "text-muted-foreground"}>
          {member.unpaid_months} months
        </span>
      ),
    },
    {
      key: "join_date",
      header: "Joined",
      render: (member: Member) => (
        <span className="text-muted-foreground">
          {new Date(member.join_date).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          })}
        </span>
      ),
    },
  ]

  const statusCounts = {
    all: members.length,
    active: members.filter((m) => m.status === "active").length,
    warning: members.filter((m) => m.status === "warning").length,
    inactive: members.filter((m) => m.status === "inactive").length,
    suspended: members.filter((m) => m.status === "suspended").length,
    resigned: members.filter((m) => m.status === "resigned").length,
  }

  return (
    <div className="flex flex-col">
      <Header title="Members" subtitle="Manage club members and their status" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList className="flex flex-wrap h-auto">
              <TabsTrigger value="all" className="text-xs sm:text-sm">
                All ({statusCounts.all})
              </TabsTrigger>
              <TabsTrigger value="active" className="text-xs sm:text-sm">
                Active ({statusCounts.active})
              </TabsTrigger>
              <TabsTrigger value="warning" className="text-xs sm:text-sm">
                Warning ({statusCounts.warning})
              </TabsTrigger>
              <TabsTrigger value="inactive" className="text-xs sm:text-sm">
                Inactive ({statusCounts.inactive})
              </TabsTrigger>
              <TabsTrigger value="suspended" className="text-xs sm:text-sm">
                Suspended ({statusCounts.suspended})
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Add Member
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Member</DialogTitle>
                <DialogDescription>Fill in the details to register a new member</DialogDescription>
              </DialogHeader>
              <MemberForm onSuccess={() => setIsAddDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Members Table */}
        <DataTable
          data={filteredMembers}
          columns={columns}
          searchKey="first_name"
          searchPlaceholder="Search by name..."
          onRowClick={(member) => setSelectedMember(member)}
        />

        {/* Member Details Dialog */}
        <Dialog open={!!selectedMember} onOpenChange={(open) => !open && setSelectedMember(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            {selectedMember && <MemberDetails member={selectedMember} onClose={() => setSelectedMember(null)} />}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
