"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { DataTable } from "@/components/dashboard/data-table"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, CreditCard, TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Payment } from "@/lib/types"
import { PaymentForm } from "@/components/payments/payment-form"
import { PaymentDetails } from "@/components/payments/payment-details"

export default function PaymentsPage() {
  const { payments, members, subscription } = useData()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null)
  const [activeTab, setActiveTab] = useState("all")

  const filteredPayments = activeTab === "all" ? payments : payments.filter((p) => p.status === activeTab)

  const statusColors: Record<string, string> = {
    completed: "bg-accent text-accent-foreground",
    pending: "bg-warning text-warning-foreground",
    failed: "bg-destructive text-destructive-foreground",
    refunded: "bg-muted text-muted-foreground",
  }

  const statusCounts = {
    all: payments.length,
    completed: payments.filter((p) => p.status === "completed").length,
    pending: payments.filter((p) => p.status === "pending").length,
    failed: payments.filter((p) => p.status === "failed").length,
  }

  // Calculate stats
  const totalCollection = payments.filter((p) => p.status === "completed").reduce((sum, p) => sum + p.total_amount, 0)
  const pendingAmount = payments.filter((p) => p.status === "pending").reduce((sum, p) => sum + p.total_amount, 0)
  const totalFines = payments.filter((p) => p.status === "completed").reduce((sum, p) => sum + p.fine_amount, 0)

  const columns = [
    {
      key: "member",
      header: "Member",
      render: (payment: Payment) => {
        const member = members.find((m) => m.id === payment.member_id)
        return member ? (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xs font-medium text-primary">
                {member.first_name[0]}
                {member.last_name[0]}
              </span>
            </div>
            <div>
              <p className="font-medium">
                {member.first_name} {member.last_name}
              </p>
              <p className="text-xs text-muted-foreground">{member.member_id}</p>
            </div>
          </div>
        ) : (
          <span className="text-muted-foreground">Unknown</span>
        )
      },
    },
    {
      key: "period",
      header: "Period",
      render: (payment: Payment) => (
        <span>
          {payment.period_month}/{payment.period_year}
        </span>
      ),
    },
    {
      key: "amount",
      header: "Amount",
      render: (payment: Payment) => <span>৳{payment.amount.toLocaleString()}</span>,
    },
    {
      key: "fine",
      header: "Fine",
      render: (payment: Payment) => (
        <span className={payment.fine_amount > 0 ? "text-destructive" : "text-muted-foreground"}>
          {payment.fine_amount > 0 ? `৳${payment.fine_amount.toLocaleString()}` : "-"}
        </span>
      ),
    },
    {
      key: "total",
      header: "Total",
      render: (payment: Payment) => <span className="font-medium">৳{payment.total_amount.toLocaleString()}</span>,
    },
    {
      key: "method",
      header: "Method",
      render: (payment: Payment) => (
        <Badge variant="outline" className="capitalize">
          {payment.payment_method}
        </Badge>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (payment: Payment) => (
        <Badge className={cn("capitalize", statusColors[payment.status])}>{payment.status}</Badge>
      ),
    },
    {
      key: "due_date",
      header: "Due Date",
      render: (payment: Payment) => <span className="text-muted-foreground">{payment.due_date}</span>,
    },
  ]

  return (
    <div className="flex flex-col">
      <Header title="Payments" subtitle="Manage member payments and subscriptions" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Collection</CardTitle>
              <TrendingUp className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">৳{totalCollection.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Payments</CardTitle>
              <Clock className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">৳{pendingAmount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">{statusCounts.pending} pending</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Fines</CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">৳{totalFines.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Collected fines</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Fee</CardTitle>
              <CreditCard className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">৳{subscription.amount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Due by {subscription.due_day}th of month</p>
            </CardContent>
          </Card>
        </div>

        {/* Subscription Info */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold">{subscription.name}</h3>
                <p className="text-sm text-muted-foreground">
                  Late payment fine: {subscription.late_fine_percentage}% after {subscription.grace_period_days} days
                  grace period
                </p>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-accent" />
                  <span>1 month unpaid = Warning</span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  <span>2 months = Inactive</span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  <span>3 months = Suspended</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
              <TabsTrigger value="completed">Completed ({statusCounts.completed})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({statusCounts.pending})</TabsTrigger>
              <TabsTrigger value="failed">Failed ({statusCounts.failed})</TabsTrigger>
            </TabsList>
          </Tabs>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Record Payment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Record Payment</DialogTitle>
                <DialogDescription>Record a new payment or generate payment dues</DialogDescription>
              </DialogHeader>
              <PaymentForm onSuccess={() => setIsAddDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Payments Table */}
        <DataTable
          data={filteredPayments}
          columns={columns}
          searchKey="member_id"
          searchPlaceholder="Search payments..."
          onRowClick={(payment) => setSelectedPayment(payment)}
        />

        {/* Payment Details Dialog */}
        <Dialog open={!!selectedPayment} onOpenChange={(open) => !open && setSelectedPayment(null)}>
          <DialogContent className="max-w-2xl">
            {selectedPayment && <PaymentDetails payment={selectedPayment} onClose={() => setSelectedPayment(null)} />}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
