"use client"

import { useEffect } from "react"
import { Header } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { useData } from "@/lib/data-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, UserCheck, UserX, AlertTriangle, CreditCard, Calendar, TrendingUp, ArrowRight } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function DashboardPage() {
  const { dashboardStats, refreshStats, members, events, payments } = useData()

  useEffect(() => {
    refreshStats()
  }, [members, events, payments, refreshStats])

  const recentMembers = members.slice(0, 5)
  const upcomingEvents = events.filter((e) => e.status === "upcoming").slice(0, 3)
  const pendingPayments = payments.filter((p) => p.status === "pending").slice(0, 5)

  const statusColors: Record<string, string> = {
    active: "bg-accent text-accent-foreground",
    warning: "bg-warning text-warning-foreground",
    inactive: "bg-muted text-muted-foreground",
    suspended: "bg-destructive text-destructive-foreground",
    resigned: "bg-secondary text-secondary-foreground",
  }

  return (
    <div className="flex flex-col">
      <Header title="Dashboard" subtitle="Welcome back! Here's an overview of your club." />

      <div className="p-4 md:p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Members"
            value={dashboardStats.totalMembers}
            description="registered members"
            icon={Users}
          />
          <StatsCard
            title="Active Members"
            value={dashboardStats.activeMembers}
            description={`${dashboardStats.warningMembers} with warnings`}
            icon={UserCheck}
            trend={{ value: 12, isPositive: true }}
          />
          <StatsCard
            title="Monthly Collection"
            value={`৳${dashboardStats.monthlyCollection.toLocaleString()}`}
            description={`${dashboardStats.pendingPayments} pending`}
            icon={CreditCard}
            trend={{ value: 8, isPositive: true }}
          />
          <StatsCard
            title="Upcoming Events"
            value={dashboardStats.upcomingEvents}
            description={`${dashboardStats.activeCommittees} active committees`}
            icon={Calendar}
          />
        </div>

        {/* Secondary Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <StatsCard
            title="Due Members"
            value={dashboardStats.dueMembers}
            description="members with pending dues"
            icon={AlertTriangle}
            className="border-warning/50"
          />
          <StatsCard
            title="Inactive Members"
            value={dashboardStats.inactiveMembers}
            description="2+ months unpaid"
            icon={UserX}
          />
          <StatsCard
            title="Total Collection"
            value={`৳${dashboardStats.totalCollection.toLocaleString()}`}
            description="all time"
            icon={TrendingUp}
          />
        </div>

        {/* Content Grid */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Recent Members */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Recent Members</CardTitle>
                <CardDescription>Latest member registrations</CardDescription>
              </div>
              <Link href="/dashboard/members">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentMembers.map((member) => (
                  <div key={member.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {member.first_name[0]}
                          {member.last_name[0]}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">
                          {member.first_name} {member.last_name}
                        </p>
                        <p className="text-sm text-muted-foreground">{member.member_id}</p>
                      </div>
                    </div>
                    <Badge className={cn("capitalize", statusColors[member.status])}>{member.status}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Upcoming Events</CardTitle>
                <CardDescription>Events scheduled this month</CardDescription>
              </div>
              <Link href="/dashboard/events">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingEvents.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No upcoming events</p>
                ) : (
                  upcomingEvents.map((event) => (
                    <div key={event.id} className="p-3 rounded-lg bg-muted/30">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium">{event.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(event.start_date).toLocaleDateString("en-US", {
                              weekday: "short",
                              month: "short",
                              day: "numeric",
                            })}
                          </p>
                        </div>
                        {event.participation_fee !== undefined && event.participation_fee > 0 && (
                          <Badge variant="secondary">৳{event.participation_fee}</Badge>
                        )}
                      </div>
                      {event.location && <p className="text-xs text-muted-foreground mt-1">{event.location}</p>}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Pending Payments */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Pending Payments</CardTitle>
                <CardDescription>Members with outstanding dues</CardDescription>
              </div>
              <Link href="/dashboard/payments">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {pendingPayments.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No pending payments</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-sm text-muted-foreground border-b border-border">
                        <th className="pb-3 font-medium">Member</th>
                        <th className="pb-3 font-medium">Period</th>
                        <th className="pb-3 font-medium">Amount</th>
                        <th className="pb-3 font-medium">Fine</th>
                        <th className="pb-3 font-medium">Total</th>
                        <th className="pb-3 font-medium">Due Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pendingPayments.map((payment) => {
                        const member = members.find((m) => m.id === payment.member_id)
                        return (
                          <tr key={payment.id} className="border-b border-border/50">
                            <td className="py-3">
                              <span className="font-medium">
                                {member ? `${member.first_name} ${member.last_name}` : "Unknown"}
                              </span>
                            </td>
                            <td className="py-3 text-muted-foreground">
                              {payment.period_month}/{payment.period_year}
                            </td>
                            <td className="py-3">৳{payment.amount.toLocaleString()}</td>
                            <td className="py-3 text-destructive">
                              {payment.fine_amount > 0 ? `৳${payment.fine_amount.toLocaleString()}` : "-"}
                            </td>
                            <td className="py-3 font-medium">৳{payment.total_amount.toLocaleString()}</td>
                            <td className="py-3 text-muted-foreground">{payment.due_date}</td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
