"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Bell, Send, Plus, CreditCard, Calendar, AlertTriangle, Info } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import type { Notification } from "@/lib/types"

export default function AdminNotificationsPage() {
  const { notifications, members, addNotification, markNotificationRead } = useData()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    user_id: "",
    title: "",
    message: "",
    type: "general" as Notification["type"],
  })

  const typeIcons: Record<string, React.ReactNode> = {
    payment_reminder: <CreditCard className="h-5 w-5" />,
    due_alert: <AlertTriangle className="h-5 w-5" />,
    suspension_warning: <AlertTriangle className="h-5 w-5" />,
    event: <Calendar className="h-5 w-5" />,
    general: <Info className="h-5 w-5" />,
  }

  const typeColors: Record<string, string> = {
    payment_reminder: "bg-primary/10 text-primary",
    due_alert: "bg-warning/10 text-warning",
    suspension_warning: "bg-destructive/10 text-destructive",
    event: "bg-accent/10 text-accent",
    general: "bg-muted text-muted-foreground",
  }

  const handleSendNotification = () => {
    if (!formData.title || !formData.message) {
      toast.error("Please fill in all fields")
      return
    }

    if (formData.user_id) {
      // Send to specific user
      addNotification({
        user_id: formData.user_id,
        title: formData.title,
        message: formData.message,
        type: formData.type,
        is_read: false,
      })
      toast.success("Notification sent")
    } else {
      // Send to all members
      members.forEach((member) => {
        addNotification({
          user_id: member.user_id,
          title: formData.title,
          message: formData.message,
          type: formData.type,
          is_read: false,
        })
      })
      toast.success(`Notification sent to ${members.length} members`)
    }

    setFormData({ user_id: "", title: "", message: "", type: "general" })
    setIsAddDialogOpen(false)
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
  }

  const typeCounts = {
    all: notifications.length,
    payment_reminder: notifications.filter((n) => n.type === "payment_reminder").length,
    due_alert: notifications.filter((n) => n.type === "due_alert").length,
    event: notifications.filter((n) => n.type === "event").length,
    general: notifications.filter((n) => n.type === "general").length,
  }

  return (
    <div className="flex flex-col">
      <Header title="Notifications" subtitle="Manage and send notifications to members" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bell className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{typeCounts.all}</p>
                  <p className="text-sm text-muted-foreground">Total Sent</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{typeCounts.payment_reminder}</p>
                  <p className="text-sm text-muted-foreground">Payment Reminders</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{typeCounts.due_alert}</p>
                  <p className="text-sm text-muted-foreground">Due Alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{typeCounts.event}</p>
                  <p className="text-sm text-muted-foreground">Event Notifications</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Send Notification */}
        <div className="flex justify-end">
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Send Notification
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Send Notification</DialogTitle>
                <DialogDescription>Send a notification to one or all members</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Recipient</Label>
                  <Select
                    value={formData.user_id}
                    onValueChange={(value) => setFormData({ ...formData, user_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All members" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Members</SelectItem>
                      {members.map((m) => (
                        <SelectItem key={m.id} value={m.user_id}>
                          {m.first_name} {m.last_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: Notification["type"]) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="payment_reminder">Payment Reminder</SelectItem>
                      <SelectItem value="due_alert">Due Alert</SelectItem>
                      <SelectItem value="event">Event</SelectItem>
                      <SelectItem value="suspension_warning">Suspension Warning</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Notification title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Message</Label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Notification message"
                    rows={3}
                  />
                </div>
                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSendNotification}>
                    <Send className="mr-2 h-4 w-4" /> Send
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Notifications List */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Notifications</CardTitle>
            <CardDescription>All notifications sent to members</CardDescription>
          </CardHeader>
          <CardContent>
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>No notifications sent yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {notifications.slice(0, 10).map((notification) => {
                  const member = members.find((m) => m.user_id === notification.user_id)
                  return (
                    <div key={notification.id} className="flex gap-4 p-3 rounded-lg bg-muted/30">
                      <div
                        className={cn(
                          "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                          typeColors[notification.type],
                        )}
                      >
                        {typeIcons[notification.type]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-medium">{notification.title}</p>
                          <span className="text-xs text-muted-foreground">{formatDate(notification.created_at)}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                        {member && (
                          <Badge variant="outline" className="mt-2 text-xs">
                            To: {member.first_name} {member.last_name}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
