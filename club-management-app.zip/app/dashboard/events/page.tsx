"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Calendar, MapPin, Users, Clock, Ticket } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Event } from "@/lib/types"
import { EventForm } from "@/components/events/event-form"
import { EventDetails } from "@/components/events/event-details"

export default function EventsPage() {
  const { events } = useData()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [activeTab, setActiveTab] = useState("upcoming")

  const filteredEvents = activeTab === "all" ? events : events.filter((e) => e.status === activeTab)

  const statusColors: Record<string, string> = {
    upcoming: "bg-primary/10 text-primary border-primary/20",
    ongoing: "bg-accent/10 text-accent border-accent/20",
    completed: "bg-muted text-muted-foreground border-border",
    cancelled: "bg-destructive/10 text-destructive border-destructive/20",
  }

  const statusCounts = {
    all: events.length,
    upcoming: events.filter((e) => e.status === "upcoming").length,
    ongoing: events.filter((e) => e.status === "ongoing").length,
    completed: events.filter((e) => e.status === "completed").length,
    cancelled: events.filter((e) => e.status === "cancelled").length,
  }

  const formatEventDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return {
      day: date.toLocaleDateString("en-US", { day: "numeric" }),
      month: date.toLocaleDateString("en-US", { month: "short" }),
      time: date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
      full: date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" }),
    }
  }

  return (
    <div className="flex flex-col">
      <Header title="Events" subtitle="Manage club events and activities" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="flex flex-wrap h-auto">
              <TabsTrigger value="all" className="text-xs sm:text-sm">
                All ({statusCounts.all})
              </TabsTrigger>
              <TabsTrigger value="upcoming" className="text-xs sm:text-sm">
                Upcoming ({statusCounts.upcoming})
              </TabsTrigger>
              <TabsTrigger value="ongoing" className="text-xs sm:text-sm">
                Ongoing ({statusCounts.ongoing})
              </TabsTrigger>
              <TabsTrigger value="completed" className="text-xs sm:text-sm">
                Completed ({statusCounts.completed})
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Create Event
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Event</DialogTitle>
                <DialogDescription>Schedule a new event for your club</DialogDescription>
              </DialogHeader>
              <EventForm onSuccess={() => setIsAddDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Events Grid */}
        {filteredEvents.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar className="mx-auto h-12 w-12 mb-4 opacity-50" />
            <p>No events found</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredEvents.map((event) => {
              const dateInfo = formatEventDate(event.start_date)

              return (
                <Card
                  key={event.id}
                  className="cursor-pointer hover:border-primary/50 transition-colors overflow-hidden"
                  onClick={() => setSelectedEvent(event)}
                >
                  <div className="flex">
                    {/* Date Badge */}
                    <div className="w-20 bg-primary/5 flex flex-col items-center justify-center py-4 border-r border-border">
                      <span className="text-2xl font-bold text-primary">{dateInfo.day}</span>
                      <span className="text-sm text-primary/70">{dateInfo.month}</span>
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between mb-2">
                        <CardTitle className="text-base line-clamp-1">{event.title}</CardTitle>
                        <Badge variant="outline" className={cn("capitalize text-xs", statusColors[event.status])}>
                          {event.status}
                        </Badge>
                      </div>

                      {event.description && (
                        <CardDescription className="line-clamp-2 mb-3">{event.description}</CardDescription>
                      )}

                      <div className="space-y-1.5 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5" />
                          <span>{dateInfo.time}</span>
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-1.5">
                            <MapPin className="h-3.5 w-3.5" />
                            <span className="line-clamp-1">{event.location}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between pt-1">
                          {event.max_participants && (
                            <div className="flex items-center gap-1.5">
                              <Users className="h-3.5 w-3.5" />
                              <span>Max {event.max_participants}</span>
                            </div>
                          )}
                          {event.participation_fee !== undefined && event.participation_fee > 0 && (
                            <div className="flex items-center gap-1.5">
                              <Ticket className="h-3.5 w-3.5" />
                              <span className="font-medium text-foreground">৳{event.participation_fee}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        )}

        {/* Event Details Dialog */}
        <Dialog open={!!selectedEvent} onOpenChange={(open) => !open && setSelectedEvent(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            {selectedEvent && <EventDetails event={selectedEvent} onClose={() => setSelectedEvent(null)} />}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
