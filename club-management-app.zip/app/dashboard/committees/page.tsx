"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Users, Calendar, Archive } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Committee } from "@/lib/types"
import { CommitteeForm } from "@/components/committees/committee-form"
import { CommitteeDetails } from "@/components/committees/committee-details"

export default function CommitteesPage() {
  const { committees, committeeMembers, members } = useData()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedCommittee, setSelectedCommittee] = useState<Committee | null>(null)
  const [activeTab, setActiveTab] = useState("active")

  const filteredCommittees = activeTab === "all" ? committees : committees.filter((c) => c.status === activeTab)

  const getCommitteeMemberCount = (committeeId: string) => {
    return committeeMembers.filter((cm) => cm.committee_id === committeeId && cm.is_active).length
  }

  const getCommitteeLeader = (committeeId: string) => {
    const leader = committeeMembers.find(
      (cm) => cm.committee_id === committeeId && (cm.role === "president" || cm.role === "treasurer") && cm.is_active,
    )
    if (!leader) return null
    const member = members.find((m) => m.id === leader.member_id)
    return member ? { ...member, role: leader.role } : null
  }

  const typeColors: Record<string, string> = {
    executive: "bg-primary/10 text-primary border-primary/20",
    advisory: "bg-accent/10 text-accent border-accent/20",
    event: "bg-warning/10 text-warning border-warning/20",
    finance: "bg-chart-2/10 text-chart-2 border-chart-2/20",
    other: "bg-muted text-muted-foreground border-border",
  }

  const statusCounts = {
    all: committees.length,
    active: committees.filter((c) => c.status === "active").length,
    archived: committees.filter((c) => c.status === "archived").length,
  }

  return (
    <div className="flex flex-col">
      <Header title="Committees" subtitle="Manage club committees and their members" />

      <div className="p-4 md:p-6 space-y-6">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
              <TabsTrigger value="active">Active ({statusCounts.active})</TabsTrigger>
              <TabsTrigger value="archived">Archived ({statusCounts.archived})</TabsTrigger>
            </TabsList>
          </Tabs>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Create Committee
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Committee</DialogTitle>
                <DialogDescription>Set up a new committee for your club</DialogDescription>
              </DialogHeader>
              <CommitteeForm onSuccess={() => setIsAddDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Committees Grid */}
        {filteredCommittees.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Users className="mx-auto h-12 w-12 mb-4 opacity-50" />
            <p>No committees found</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredCommittees.map((committee) => {
              const memberCount = getCommitteeMemberCount(committee.id)
              const leader = getCommitteeLeader(committee.id)

              return (
                <Card
                  key={committee.id}
                  className="cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => setSelectedCommittee(committee)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{committee.name}</CardTitle>
                        <CardDescription className="line-clamp-2">{committee.description}</CardDescription>
                      </div>
                      <Badge variant="outline" className={cn("capitalize", typeColors[committee.type])}>
                        {committee.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {/* Leader */}
                      {leader && (
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-xs font-medium text-primary">
                              {leader.first_name[0]}
                              {leader.last_name[0]}
                            </span>
                          </div>
                          <span className="text-sm">
                            {leader.first_name} {leader.last_name}
                          </span>
                          <Badge variant="secondary" className="text-xs capitalize">
                            {leader.role.replace("_", " ")}
                          </Badge>
                        </div>
                      )}

                      {/* Stats */}
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          <span>{memberCount} members</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(committee.start_date).getFullYear()}</span>
                        </div>
                      </div>

                      {/* Status */}
                      {committee.status === "archived" && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Archive className="h-3 w-3" />
                          <span>Archived</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}

        {/* Committee Details Dialog */}
        <Dialog open={!!selectedCommittee} onOpenChange={(open) => !open && setSelectedCommittee(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            {selectedCommittee && (
              <CommitteeDetails committee={selectedCommittee} onClose={() => setSelectedCommittee(null)} />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
