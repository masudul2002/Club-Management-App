"use client"

import { useState } from "react"
import type { Member } from "@/lib/types"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import { Edit, Trash2, Mail, Phone, MapPin, Calendar, CreditCard, Users } from "lucide-react"
import { toast } from "sonner"
import { MemberForm } from "./member-form"

interface MemberDetailsProps {
  member: Member
  onClose: () => void
}

export function MemberDetails({ member, onClose }: MemberDetailsProps) {
  const { deleteMember, payments, committeeMembers, committees } = useData()
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)

  const statusColors: Record<string, string> = {
    active: "bg-accent text-accent-foreground",
    warning: "bg-warning text-warning-foreground",
    inactive: "bg-muted text-muted-foreground",
    suspended: "bg-destructive text-destructive-foreground",
    resigned: "bg-secondary text-secondary-foreground",
  }

  const memberPayments = payments.filter((p) => p.member_id === member.id)
  const memberCommittees = committeeMembers
    .filter((cm) => cm.member_id === member.id && cm.is_active)
    .map((cm) => ({
      ...cm,
      committee: committees.find((c) => c.id === cm.committee_id),
    }))

  const handleDelete = () => {
    deleteMember(member.id)
    toast.success("Member deleted successfully")
    onClose()
  }

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl font-bold text-primary">
                {member.first_name[0]}
                {member.last_name[0]}
              </span>
            </div>
            <div>
              <h2 className="text-xl font-bold">
                {member.first_name} {member.last_name}
              </h2>
              <p className="text-muted-foreground font-mono">{member.member_id}</p>
              <Badge className={cn("mt-1 capitalize", statusColors[member.status])}>{member.status}</Badge>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowEditDialog(true)}>
              <Edit className="h-4 w-4 mr-1" /> Edit
            </Button>
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteDialog(true)}>
              <Trash2 className="h-4 w-4 mr-1" /> Delete
            </Button>
          </div>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="info" className="w-full">
          <TabsList>
            <TabsTrigger value="info">Information</TabsTrigger>
            <TabsTrigger value="payments">Payments ({memberPayments.length})</TabsTrigger>
            <TabsTrigger value="committees">Committees ({memberCommittees.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-4 mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{member.email}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{member.phone}</span>
                  </div>
                  {member.address && (
                    <div className="flex items-center gap-3">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{member.address}</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Membership Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>
                      Joined:{" "}
                      {new Date(member.join_date).toLocaleDateString("en-US", {
                        month: "long",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  {member.date_of_birth && (
                    <div className="flex items-center gap-3">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>
                        DOB:{" "}
                        {new Date(member.date_of_birth).toLocaleDateString("en-US", {
                          month: "long",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-4 w-4 text-muted-foreground" />
                    <span className={member.unpaid_months > 0 ? "text-destructive" : ""}>
                      Unpaid Months: {member.unpaid_months}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Payment Status Warning */}
            {member.unpaid_months > 0 && (
              <Card className="border-warning/50 bg-warning/5">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2 text-warning">
                    <CreditCard className="h-5 w-5" />
                    <span className="font-medium">
                      This member has {member.unpaid_months} unpaid month(s).{" "}
                      {member.unpaid_months >= 3 && "Account is suspended due to non-payment."}
                      {member.unpaid_months === 2 && "Account will be suspended after 1 more month."}
                      {member.unpaid_months === 1 && "This is a warning. Payment is overdue."}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="payments" className="mt-4">
            {memberPayments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No payment records found</div>
            ) : (
              <div className="space-y-2">
                {memberPayments.map((payment) => (
                  <Card key={payment.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">
                            {payment.period_month}/{payment.period_year}
                          </p>
                          <p className="text-sm text-muted-foreground">Due: {payment.due_date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">৳{payment.total_amount.toLocaleString()}</p>
                          <Badge
                            variant={payment.status === "completed" ? "default" : "secondary"}
                            className={cn(
                              payment.status === "completed" && "bg-accent text-accent-foreground",
                              payment.status === "pending" && "bg-warning text-warning-foreground",
                              payment.status === "failed" && "bg-destructive text-destructive-foreground",
                            )}
                          >
                            {payment.status}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="committees" className="mt-4">
            {memberCommittees.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">Not a member of any committee</div>
            ) : (
              <div className="space-y-2">
                {memberCommittees.map((cm) => (
                  <Card key={cm.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Users className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{cm.committee?.name}</p>
                            <p className="text-sm text-muted-foreground capitalize">{cm.role.replace("_", " ")}</p>
                          </div>
                        </div>
                        <Badge variant="outline">{cm.committee?.type}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {member.first_name} {member.last_name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Member</DialogTitle>
            <DialogDescription>Update member information</DialogDescription>
          </DialogHeader>
          <MemberForm
            member={member}
            onSuccess={() => {
              setShowEditDialog(false)
              onClose()
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
