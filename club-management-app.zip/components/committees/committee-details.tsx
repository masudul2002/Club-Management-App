"use client"

import { useState } from "react"
import type { Committee, CommitteeMember as CommitteeMemberType } from "@/lib/types"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import { Edit, Trash2, UserPlus, Calendar, X } from "lucide-react"
import { toast } from "sonner"
import { CommitteeForm } from "./committee-form"

interface CommitteeDetailsProps {
  committee: Committee
  onClose: () => void
}

export function CommitteeDetails({ committee, onClose }: CommitteeDetailsProps) {
  const { deleteCommittee, committeeMembers, members, addCommitteeMember, removeCommitteeMember } = useData()
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showAddMemberDialog, setShowAddMemberDialog] = useState(false)
  const [selectedMemberId, setSelectedMemberId] = useState("")
  const [selectedRole, setSelectedRole] = useState<CommitteeMemberType["role"]>("member")

  const typeColors: Record<string, string> = {
    executive: "bg-primary/10 text-primary",
    advisory: "bg-accent/10 text-accent",
    event: "bg-warning/10 text-warning",
    finance: "bg-chart-2/10 text-chart-2",
    other: "bg-muted text-muted-foreground",
  }

  const committeeMembs = committeeMembers
    .filter((cm) => cm.committee_id === committee.id && cm.is_active)
    .map((cm) => ({
      ...cm,
      member: members.find((m) => m.id === cm.member_id),
    }))

  const availableMembers = members.filter(
    (m) => m.status === "active" && !committeeMembs.some((cm) => cm.member_id === m.id),
  )

  const handleDelete = () => {
    deleteCommittee(committee.id)
    toast.success("Committee deleted successfully")
    onClose()
  }

  const handleAddMember = () => {
    if (!selectedMemberId) {
      toast.error("Please select a member")
      return
    }

    addCommitteeMember({
      committee_id: committee.id,
      member_id: selectedMemberId,
      role: selectedRole,
      start_date: new Date().toISOString().split("T")[0],
      is_active: true,
    })

    toast.success("Member added to committee")
    setShowAddMemberDialog(false)
    setSelectedMemberId("")
    setSelectedRole("member")
  }

  const handleRemoveMember = (cmId: string) => {
    removeCommitteeMember(cmId)
    toast.success("Member removed from committee")
  }

  const roleOrder = ["president", "vice_president", "secretary", "treasurer", "member"]
  const sortedMembers = [...committeeMembs].sort((a, b) => roleOrder.indexOf(a.role) - roleOrder.indexOf(b.role))

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold">{committee.name}</h2>
              <Badge className={cn("capitalize", typeColors[committee.type])}>{committee.type}</Badge>
              <Badge variant={committee.status === "active" ? "default" : "secondary"}>{committee.status}</Badge>
            </div>
            <p className="text-muted-foreground">{committee.description}</p>
            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>
                  {new Date(committee.start_date).toLocaleDateString()} -{" "}
                  {committee.end_date ? new Date(committee.end_date).toLocaleDateString() : "Present"}
                </span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowEditDialog(true)}>
              <Edit className="h-4 w-4 mr-1" /> Edit
            </Button>
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteDialog(true)}>
              <Trash2 className="h-4 w-4 mr-1" /> Delete
            </Button>
          </div>
        </div>

        {/* Members Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Committee Members ({committeeMembs.length})</CardTitle>
            <Dialog open={showAddMemberDialog} onOpenChange={setShowAddMemberDialog}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <UserPlus className="h-4 w-4 mr-1" /> Add Member
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Committee Member</DialogTitle>
                  <DialogDescription>Select a member and assign their role in this committee</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Select Member</Label>
                    <Select value={selectedMemberId} onValueChange={setSelectedMemberId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a member" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableMembers.length === 0 ? (
                          <div className="p-2 text-sm text-muted-foreground">No available members</div>
                        ) : (
                          availableMembers.map((m) => (
                            <SelectItem key={m.id} value={m.id}>
                              {m.first_name} {m.last_name} ({m.member_id})
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Select
                      value={selectedRole}
                      onValueChange={(v) => setSelectedRole(v as CommitteeMemberType["role"])}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="president">President</SelectItem>
                        <SelectItem value="vice_president">Vice President</SelectItem>
                        <SelectItem value="secretary">Secretary</SelectItem>
                        <SelectItem value="treasurer">Treasurer</SelectItem>
                        <SelectItem value="member">Member</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setShowAddMemberDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddMember}>Add Member</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {sortedMembers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No members in this committee</div>
            ) : (
              <div className="space-y-2">
                {sortedMembers.map((cm) => (
                  <div key={cm.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {cm.member?.first_name[0]}
                          {cm.member?.last_name[0]}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">
                          {cm.member?.first_name} {cm.member?.last_name}
                        </p>
                        <p className="text-sm text-muted-foreground">{cm.member?.member_id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="capitalize">
                        {cm.role.replace("_", " ")}
                      </Badge>
                      <Button variant="ghost" size="icon" onClick={() => handleRemoveMember(cm.id)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Committee</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {committee.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Committee</DialogTitle>
            <DialogDescription>Update committee information</DialogDescription>
          </DialogHeader>
          <CommitteeForm
            committee={committee}
            onSuccess={() => {
              setShowEditDialog(false)
              onClose()
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
