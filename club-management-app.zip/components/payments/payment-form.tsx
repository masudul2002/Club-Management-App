"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "sonner"
import { Loader2, CreditCard } from "lucide-react"
import type { Payment, PaymentStatus } from "@/lib/types"

interface PaymentFormProps {
  payment?: Payment
  onSuccess: () => void
}

export function PaymentForm({ payment, onSuccess }: PaymentFormProps) {
  const { addPayment, updatePayment, members, subscription, payments } = useData()
  const [isLoading, setIsLoading] = useState(false)
  const [isProcessingBkash, setIsProcessingBkash] = useState(false)

  const currentDate = new Date()
  const currentMonth = currentDate.getMonth() + 1
  const currentYear = currentDate.getFullYear()

  const [formData, setFormData] = useState({
    member_id: payment?.member_id || "",
    period_month: payment?.period_month?.toString() || currentMonth.toString(),
    period_year: payment?.period_year?.toString() || currentYear.toString(),
    amount: payment?.amount?.toString() || subscription.amount.toString(),
    fine_amount: payment?.fine_amount?.toString() || "0",
    payment_method: payment?.payment_method || ("bkash" as Payment["payment_method"]),
    transaction_id: payment?.transaction_id || "",
    status: payment?.status || ("pending" as PaymentStatus),
    notes: payment?.notes || "",
  })

  // Calculate if fine applies
  const calculateFine = useMemo(() => {
    if (!formData.member_id) return 0

    const dueDay = subscription.due_day
    const today = new Date()
    const dueDate = new Date(Number(formData.period_year), Number(formData.period_month) - 1, dueDay)

    // Add grace period
    dueDate.setDate(dueDate.getDate() + subscription.grace_period_days)

    if (today > dueDate) {
      return Math.round((Number(formData.amount) * subscription.late_fine_percentage) / 100)
    }
    return 0
  }, [formData.member_id, formData.period_month, formData.period_year, formData.amount, subscription])

  const totalAmount = Number(formData.amount) + (Number(formData.fine_amount) || calculateFine)

  // Get members who have pending dues
  const activeMembers = members.filter((m) => m.status !== "resigned")

  // Check if payment already exists for this member and period
  const existingPayment = payments.find(
    (p) =>
      p.member_id === formData.member_id &&
      p.period_month === Number(formData.period_month) &&
      p.period_year === Number(formData.period_year) &&
      p.id !== payment?.id,
  )

  const handleBkashPayment = async () => {
    if (!formData.member_id) {
      toast.error("Please select a member")
      return
    }

    setIsProcessingBkash(true)

    // Simulate bKash payment process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate mock transaction ID
    const txnId = `BK${Date.now().toString().slice(-10)}`
    setFormData({ ...formData, transaction_id: txnId, status: "completed" })

    setIsProcessingBkash(false)
    toast.success("bKash payment simulation completed!")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (existingPayment) {
      toast.error("Payment already exists for this member and period")
      return
    }

    setIsLoading(true)

    try {
      const dueDay = subscription.due_day
      const dueDate = `${formData.period_year}-${String(formData.period_month).padStart(2, "0")}-${String(dueDay).padStart(2, "0")}`

      const paymentData = {
        member_id: formData.member_id,
        subscription_id: subscription.id,
        amount: Number(formData.amount),
        fine_amount: Number(formData.fine_amount) || calculateFine,
        total_amount: totalAmount,
        payment_method: formData.payment_method,
        transaction_id: formData.transaction_id || undefined,
        status: formData.status,
        payment_date: formData.status === "completed" ? new Date().toISOString().split("T")[0] : undefined,
        due_date: dueDate,
        period_month: Number(formData.period_month),
        period_year: Number(formData.period_year),
        notes: formData.notes || undefined,
      }

      if (payment) {
        updatePayment(payment.id, paymentData)
        toast.success("Payment updated successfully")
      } else {
        addPayment(paymentData)
        toast.success("Payment recorded successfully")
      }
      onSuccess()
    } catch {
      toast.error("An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const selectedMember = members.find((m) => m.id === formData.member_id)

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2 col-span-2">
          <Label htmlFor="member">Select Member *</Label>
          <Select value={formData.member_id} onValueChange={(value) => setFormData({ ...formData, member_id: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a member" />
            </SelectTrigger>
            <SelectContent>
              {activeMembers.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  {m.first_name} {m.last_name} ({m.member_id})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="period_month">Month *</Label>
          <Select
            value={formData.period_month}
            onValueChange={(value) => setFormData({ ...formData, period_month: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 12 }, (_, i) => (
                <SelectItem key={i + 1} value={(i + 1).toString()}>
                  {new Date(2024, i).toLocaleString("default", { month: "long" })}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="period_year">Year *</Label>
          <Select
            value={formData.period_year}
            onValueChange={(value) => setFormData({ ...formData, period_year: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[2024, 2025, 2026].map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Payment Summary */}
      {selectedMember && (
        <Card className="bg-muted/30">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-muted-foreground">Member</span>
              <span className="font-medium">
                {selectedMember.first_name} {selectedMember.last_name}
              </span>
            </div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-muted-foreground">Monthly Fee</span>
              <span>৳{Number(formData.amount).toLocaleString()}</span>
            </div>
            {calculateFine > 0 && (
              <div className="flex items-center justify-between mb-3 text-destructive">
                <span className="text-sm">Late Payment Fine ({subscription.late_fine_percentage}%)</span>
                <span>৳{calculateFine.toLocaleString()}</span>
              </div>
            )}
            <div className="flex items-center justify-between pt-3 border-t border-border">
              <span className="font-medium">Total Amount</span>
              <span className="text-lg font-bold">৳{totalAmount.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="payment_method">Payment Method *</Label>
          <Select
            value={formData.payment_method}
            onValueChange={(value: Payment["payment_method"]) => setFormData({ ...formData, payment_method: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="bkash">bKash</SelectItem>
              <SelectItem value="nagad">Nagad</SelectItem>
              <SelectItem value="cash">Cash</SelectItem>
              <SelectItem value="bank">Bank Transfer</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">Status *</Label>
          <Select
            value={formData.status}
            onValueChange={(value: PaymentStatus) => setFormData({ ...formData, status: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {formData.payment_method === "bkash" && (
        <Card className="border-[#E2136E]/30 bg-[#E2136E]/5">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#E2136E] flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-medium">bKash Payment</p>
                  <p className="text-sm text-muted-foreground">Simulate bKash payment process</p>
                </div>
              </div>
              <Button
                type="button"
                onClick={handleBkashPayment}
                disabled={isProcessingBkash || !formData.member_id}
                className="bg-[#E2136E] hover:bg-[#E2136E]/90"
              >
                {isProcessingBkash && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Pay with bKash
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        <Label htmlFor="transaction_id">Transaction ID</Label>
        <Input
          id="transaction_id"
          value={formData.transaction_id}
          onChange={(e) => setFormData({ ...formData, transaction_id: e.target.value })}
          placeholder="Enter transaction ID (if available)"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Any additional notes"
          rows={2}
        />
      </div>

      {existingPayment && (
        <p className="text-sm text-destructive">A payment for this member and period already exists.</p>
      )}

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading || !!existingPayment}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {payment ? "Update Payment" : "Record Payment"}
        </Button>
      </div>
    </form>
  )
}
