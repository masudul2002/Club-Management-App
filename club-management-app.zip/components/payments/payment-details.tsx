"use client"

import type React from "react"

import { useState } from "react"
import type { Payment } from "@/lib/types"
import { useData } from "@/lib/data-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import { Edit, CheckCircle, XCircle, Clock, RefreshCw, CreditCard, Calendar, User, Hash } from "lucide-react"
import { toast } from "sonner"
import { PaymentForm } from "./payment-form"

interface PaymentDetailsProps {
  payment: Payment
  onClose: () => void
}

export function PaymentDetails({ payment, onClose }: PaymentDetailsProps) {
  const { members, updatePayment, updateMember } = useData()
  const [showEditDialog, setShowEditDialog] = useState(false)

  const member = members.find((m) => m.id === payment.member_id)

  const statusColors: Record<string, string> = {
    completed: "bg-accent text-accent-foreground",
    pending: "bg-warning text-warning-foreground",
    failed: "bg-destructive text-destructive-foreground",
    refunded: "bg-muted text-muted-foreground",
  }

  const statusIcons: Record<string, React.ReactNode> = {
    completed: <CheckCircle className="h-5 w-5" />,
    pending: <Clock className="h-5 w-5" />,
    failed: <XCircle className="h-5 w-5" />,
    refunded: <RefreshCw className="h-5 w-5" />,
  }

  const handleMarkComplete = () => {
    updatePayment(payment.id, {
      status: "completed",
      payment_date: new Date().toISOString().split("T")[0],
    })

    // Update member's unpaid months if applicable
    if (member && member.unpaid_months > 0) {
      const newUnpaidMonths = Math.max(0, member.unpaid_months - 1)
      let newStatus = member.status

      if (newUnpaidMonths === 0) {
        newStatus = "active"
      } else if (newUnpaidMonths === 1) {
        newStatus = "warning"
      } else if (newUnpaidMonths === 2) {
        newStatus = "inactive"
      }

      updateMember(member.id, {
        unpaid_months: newUnpaidMonths,
        status: newStatus,
      })
    }

    toast.success("Payment marked as completed")
    onClose()
  }

  const handleMarkFailed = () => {
    updatePayment(payment.id, { status: "failed" })
    toast.success("Payment marked as failed")
    onClose()
  }

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div
                className={cn("w-12 h-12 rounded-full flex items-center justify-center", statusColors[payment.status])}
              >
                {statusIcons[payment.status]}
              </div>
              <div>
                <h2 className="text-xl font-bold">Payment #{payment.id.slice(-6)}</h2>
                <Badge className={cn("capitalize", statusColors[payment.status])}>{payment.status}</Badge>
              </div>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setShowEditDialog(true)}>
            <Edit className="h-4 w-4 mr-1" /> Edit
          </Button>
        </div>

        {/* Member Info */}
        {member && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Member Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-lg font-medium text-primary">
                    {member.first_name[0]}
                    {member.last_name[0]}
                  </span>
                </div>
                <div>
                  <p className="font-medium">
                    {member.first_name} {member.last_name}
                  </p>
                  <p className="text-sm text-muted-foreground">{member.member_id}</p>
                  <p className="text-sm text-muted-foreground">{member.email}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Details */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Payment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>
                  Period: {payment.period_month}/{payment.period_year}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>Due Date: {payment.due_date}</span>
              </div>
              {payment.payment_date && (
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-4 w-4 text-accent" />
                  <span>Paid on: {payment.payment_date}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Transaction Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <span className="capitalize">{payment.payment_method}</span>
              </div>
              {payment.transaction_id && (
                <div className="flex items-center gap-3">
                  <Hash className="h-4 w-4 text-muted-foreground" />
                  <span className="font-mono text-sm">{payment.transaction_id}</span>
                </div>
              )}
              {payment.notes && (
                <div className="flex items-start gap-3">
                  <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <span className="text-sm">{payment.notes}</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Amount Breakdown */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Amount Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Base Amount</span>
                <span>৳{payment.amount.toLocaleString()}</span>
              </div>
              {payment.fine_amount > 0 && (
                <div className="flex items-center justify-between text-destructive">
                  <span>Late Payment Fine</span>
                  <span>৳{payment.fine_amount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex items-center justify-between pt-2 border-t border-border">
                <span className="font-medium">Total Amount</span>
                <span className="text-lg font-bold">৳{payment.total_amount.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        {payment.status === "pending" && (
          <div className="flex gap-3">
            <Button onClick={handleMarkComplete} className="flex-1 bg-accent hover:bg-accent/90">
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Completed
            </Button>
            <Button onClick={handleMarkFailed} variant="destructive" className="flex-1">
              <XCircle className="h-4 w-4 mr-2" />
              Mark as Failed
            </Button>
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Payment</DialogTitle>
            <DialogDescription>Update payment information</DialogDescription>
          </DialogHeader>
          <PaymentForm
            payment={payment}
            onSuccess={() => {
              setShowEditDialog(false)
              onClose()
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
