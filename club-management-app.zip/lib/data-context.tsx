"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type {
  Member,
  Committee,
  CommitteeMember,
  Event,
  Payment,
  Notification,
  Subscription,
  DashboardStats,
} from "./types"
import {
  mockMembers,
  mockCommittees,
  mockCommitteeMembers,
  mockEvents,
  mockPayments,
  mockNotifications,
  mockSubscription,
  mockDashboardStats,
} from "./mock-data"

interface DataContextType {
  // Members
  members: Member[]
  addMember: (member: Omit<Member, "id" | "created_at" | "updated_at">) => void
  updateMember: (id: string, updates: Partial<Member>) => void
  deleteMember: (id: string) => void

  // Committees
  committees: Committee[]
  addCommittee: (committee: Omit<Committee, "id" | "created_at" | "updated_at">) => void
  updateCommittee: (id: string, updates: Partial<Committee>) => void
  deleteCommittee: (id: string) => void

  // Committee Members
  committeeMembers: CommitteeMember[]
  addCommitteeMember: (cm: Omit<CommitteeMember, "id">) => void
  removeCommitteeMember: (id: string) => void

  // Events
  events: Event[]
  addEvent: (event: Omit<Event, "id" | "created_at" | "updated_at">) => void
  updateEvent: (id: string, updates: Partial<Event>) => void
  deleteEvent: (id: string) => void

  // Payments
  payments: Payment[]
  addPayment: (payment: Omit<Payment, "id" | "created_at" | "updated_at">) => void
  updatePayment: (id: string, updates: Partial<Payment>) => void

  // Notifications
  notifications: Notification[]
  addNotification: (notification: Omit<Notification, "id" | "created_at">) => void
  markNotificationRead: (id: string) => void
  markAllNotificationsRead: () => void

  // Subscription
  subscription: Subscription
  updateSubscription: (updates: Partial<Subscription>) => void

  // Stats
  dashboardStats: DashboardStats
  refreshStats: () => void
}

const DataContext = createContext<DataContextType | undefined>(undefined)

export function DataProvider({ children }: { children: ReactNode }) {
  const [members, setMembers] = useState<Member[]>(mockMembers)
  const [committees, setCommittees] = useState<Committee[]>(mockCommittees)
  const [committeeMembers, setCommitteeMembers] = useState<CommitteeMember[]>(mockCommitteeMembers)
  const [events, setEvents] = useState<Event[]>(mockEvents)
  const [payments, setPayments] = useState<Payment[]>(mockPayments)
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)
  const [subscription, setSubscription] = useState<Subscription>(mockSubscription)
  const [dashboardStats, setDashboardStats] = useState<DashboardStats>(mockDashboardStats)

  // Member operations
  const addMember = (member: Omit<Member, "id" | "created_at" | "updated_at">) => {
    const newMember: Member = {
      ...member,
      id: `${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setMembers((prev) => [...prev, newMember])
  }

  const updateMember = (id: string, updates: Partial<Member>) => {
    setMembers((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates, updated_at: new Date().toISOString() } : m)),
    )
  }

  const deleteMember = (id: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== id))
  }

  // Committee operations
  const addCommittee = (committee: Omit<Committee, "id" | "created_at" | "updated_at">) => {
    const newCommittee: Committee = {
      ...committee,
      id: `${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setCommittees((prev) => [...prev, newCommittee])
  }

  const updateCommittee = (id: string, updates: Partial<Committee>) => {
    setCommittees((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates, updated_at: new Date().toISOString() } : c)),
    )
  }

  const deleteCommittee = (id: string) => {
    setCommittees((prev) => prev.filter((c) => c.id !== id))
  }

  // Committee Member operations
  const addCommitteeMember = (cm: Omit<CommitteeMember, "id">) => {
    const newCM: CommitteeMember = {
      ...cm,
      id: `${Date.now()}`,
    }
    setCommitteeMembers((prev) => [...prev, newCM])
  }

  const removeCommitteeMember = (id: string) => {
    setCommitteeMembers((prev) => prev.filter((cm) => cm.id !== id))
  }

  // Event operations
  const addEvent = (event: Omit<Event, "id" | "created_at" | "updated_at">) => {
    const newEvent: Event = {
      ...event,
      id: `${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setEvents((prev) => [...prev, newEvent])
  }

  const updateEvent = (id: string, updates: Partial<Event>) => {
    setEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates, updated_at: new Date().toISOString() } : e)))
  }

  const deleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id))
  }

  // Payment operations
  const addPayment = (payment: Omit<Payment, "id" | "created_at" | "updated_at">) => {
    const newPayment: Payment = {
      ...payment,
      id: `${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setPayments((prev) => [...prev, newPayment])
  }

  const updatePayment = (id: string, updates: Partial<Payment>) => {
    setPayments((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates, updated_at: new Date().toISOString() } : p)),
    )
  }

  // Notification operations
  const addNotification = (notification: Omit<Notification, "id" | "created_at">) => {
    const newNotification: Notification = {
      ...notification,
      id: `${Date.now()}`,
      created_at: new Date().toISOString(),
    }
    setNotifications((prev) => [newNotification, ...prev])
  }

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)))
  }

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })))
  }

  // Subscription operations
  const updateSubscription = (updates: Partial<Subscription>) => {
    setSubscription((prev) => ({ ...prev, ...updates }))
  }

  // Stats operations
  const refreshStats = () => {
    const activeMembers = members.filter((m) => m.status === "active").length
    const inactiveMembers = members.filter((m) => m.status === "inactive").length
    const suspendedMembers = members.filter((m) => m.status === "suspended").length
    const warningMembers = members.filter((m) => m.status === "warning").length
    const dueMembers = members.filter((m) => m.unpaid_months > 0).length

    const completedPayments = payments.filter((p) => p.status === "completed")
    const totalCollection = completedPayments.reduce((sum, p) => sum + p.total_amount, 0)

    const currentMonth = new Date().getMonth() + 1
    const currentYear = new Date().getFullYear()
    const monthlyCollection = completedPayments
      .filter((p) => p.period_month === currentMonth && p.period_year === currentYear)
      .reduce((sum, p) => sum + p.total_amount, 0)

    const pendingPayments = payments.filter((p) => p.status === "pending").length
    const upcomingEvents = events.filter((e) => e.status === "upcoming").length
    const activeCommittees = committees.filter((c) => c.status === "active").length

    setDashboardStats({
      totalMembers: members.length,
      activeMembers,
      inactiveMembers,
      suspendedMembers,
      warningMembers,
      dueMembers,
      totalCollection,
      monthlyCollection,
      pendingPayments,
      upcomingEvents,
      activeCommittees,
    })
  }

  return (
    <DataContext.Provider
      value={{
        members,
        addMember,
        updateMember,
        deleteMember,
        committees,
        addCommittee,
        updateCommittee,
        deleteCommittee,
        committeeMembers,
        addCommitteeMember,
        removeCommitteeMember,
        events,
        addEvent,
        updateEvent,
        deleteEvent,
        payments,
        addPayment,
        updatePayment,
        notifications,
        addNotification,
        markNotificationRead,
        markAllNotificationsRead,
        subscription,
        updateSubscription,
        dashboardStats,
        refreshStats,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}
