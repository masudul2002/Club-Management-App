// Core types for the Club Management System

export type UserRole = "super_admin" | "admin" | "editor" | "member" | "public"

export type MemberStatus = "active" | "inactive" | "suspended" | "resigned" | "warning"

export type PaymentStatus = "pending" | "completed" | "failed" | "refunded"

export type CommitteeStatus = "active" | "archived"

export type EventStatus = "upcoming" | "ongoing" | "completed" | "cancelled"

export interface User {
  id: string
  email: string
  phone: string
  password_hash: string
  role: UserRole
  created_at: string
  updated_at: string
  last_login?: string
  is_active: boolean
}

export interface Member {
  id: string
  user_id: string
  member_id: string // Unique member ID like "CLB-001"
  first_name: string
  last_name: string
  email: string
  phone: string
  address?: string
  photo_url?: string
  date_of_birth?: string
  join_date: string
  status: MemberStatus
  unpaid_months: number
  created_at: string
  updated_at: string
}

export interface Committee {
  id: string
  name: string
  description?: string
  type: "executive" | "advisory" | "event" | "finance" | "other"
  start_date: string
  end_date?: string
  status: CommitteeStatus
  created_at: string
  updated_at: string
}

export interface CommitteeMember {
  id: string
  committee_id: string
  member_id: string
  role: "president" | "vice_president" | "secretary" | "treasurer" | "member"
  start_date: string
  end_date?: string
  is_active: boolean
}

export interface Event {
  id: string
  title: string
  description?: string
  location?: string
  start_date: string
  end_date?: string
  registration_deadline?: string
  participation_fee?: number
  max_participants?: number
  status: EventStatus
  created_by: string
  created_at: string
  updated_at: string
}

export interface EventParticipant {
  id: string
  event_id: string
  member_id: string
  registration_date: string
  attended: boolean
  payment_status: PaymentStatus
}

export interface Subscription {
  id: string
  name: string
  amount: number
  due_day: number // Day of month (1-28)
  late_fine_percentage: number
  grace_period_days: number
  is_active: boolean
  created_at: string
}

export interface Payment {
  id: string
  member_id: string
  subscription_id?: string
  event_id?: string
  amount: number
  fine_amount: number
  total_amount: number
  payment_method: "bkash" | "nagad" | "sslcommerz" | "cash" | "bank"
  transaction_id?: string
  status: PaymentStatus
  payment_date?: string
  due_date: string
  period_month: number // 1-12
  period_year: number
  notes?: string
  created_at: string
  updated_at: string
}

export interface Fine {
  id: string
  member_id: string
  payment_id?: string
  amount: number
  reason: string
  is_paid: boolean
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: "payment_reminder" | "due_alert" | "suspension_warning" | "event" | "general"
  is_read: boolean
  created_at: string
}

export interface AuditLog {
  id: string
  user_id: string
  action: string
  entity_type: string
  entity_id: string
  old_value?: string
  new_value?: string
  ip_address?: string
  created_at: string
}

// Dashboard Statistics
export interface DashboardStats {
  totalMembers: number
  activeMembers: number
  inactiveMembers: number
  suspendedMembers: number
  warningMembers: number
  dueMembers: number
  totalCollection: number
  monthlyCollection: number
  pendingPayments: number
  upcomingEvents: number
  activeCommittees: number
}

export interface MemberDashboardStats {
  paymentStatus: "paid" | "due" | "overdue"
  dueAmount: number
  fineAmount: number
  upcomingEvents: number
  committeePositions: number
  nextDueDate: string
}

// Form types
export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  email: string
  phone: string
  password: string
  first_name: string
  last_name: string
}

// API Response types
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}
